﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Symbols
{
    public class SubStatemantSymbol : Symbol
    {
        public SubStatemantSymbol(string name)
            : base(name, SymbolKind.SubStatemant)
        { }
    }
}
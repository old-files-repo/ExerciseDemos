﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Keywords
{
    public static class SubStatements
    {
        public const string Many = "many";
        public const string Much = "much";
    }
}
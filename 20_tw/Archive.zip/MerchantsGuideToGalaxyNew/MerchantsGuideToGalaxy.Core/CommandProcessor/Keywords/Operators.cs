﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Keywords
{
    public static class Operators
    {
        public const string Is = "is";
    }
}
﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Keywords
{
    public static class RomanSymbols
    {
        public const string I = "I";
        public const string V = "V";
        public const string X = "X";
        public const string L = "L";
        public const string C = "C";
        public const string D = "D";
        public const string M = "M";
    }
}
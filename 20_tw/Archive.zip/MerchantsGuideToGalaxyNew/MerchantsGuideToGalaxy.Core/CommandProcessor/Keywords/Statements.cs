﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Keywords
{
    public static class Statements
    {
        public const string How = "how";
    }
}
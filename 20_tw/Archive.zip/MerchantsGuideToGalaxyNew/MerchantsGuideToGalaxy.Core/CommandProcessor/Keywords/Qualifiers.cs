﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Keywords
{
    public static class Qualifiers
    {
        public const string QueryCommandQualifier = "?";
    }
}

﻿using System;

namespace MerchantsGuideToGalaxy.Core.CommandProcessor
{
    public class ParsingException: Exception
    {
    }
}

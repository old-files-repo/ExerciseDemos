﻿using System;

namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Commands
{
    public class DuplicatedDeclarationException: Exception
    {
    }
}

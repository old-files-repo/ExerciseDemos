﻿namespace MerchantsGuideToGalaxy.Core.CommandProcessor.Commands
{
    public class CommandResult
    {
        public string ResultText { get; set; }

        public bool Sucess { get; set; }
    }
}

﻿using System;

namespace MerchantsGuideToGalaxy.Core.Roman
{
    public class InvalidRomanNumberException: Exception
    {
    }
}

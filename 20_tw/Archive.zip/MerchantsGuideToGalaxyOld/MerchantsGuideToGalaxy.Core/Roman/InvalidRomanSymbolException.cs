﻿namespace MerchantsGuideToGalaxy.Core.Roman
{
    public class InvalidRomanSymbolException: InvalidRomanNumberException
    {
    }
}

﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WorkflowCore.Interface;
using WorkflowCoreTestWebAPI.Models;

namespace WorkflowCoreTestWebAPI.Controllers
{
    [Route("api/[controller]")]
    public class AskForLeaveController : Controller
    {
        private readonly IWorkflowHost _workflowHost;
        private readonly IPersistenceProvider _persistenceProvider;

        public AskForLeaveController(IWorkflowHost workflowHost, 
            IPersistenceProvider persistenceProvider)
        {
            _workflowHost = workflowHost;
            _persistenceProvider = persistenceProvider;
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody]AskForLeaveInfo askForLeaveInfo)
        {
            askForLeaveInfo.Id = Guid.NewGuid();
            AskForLeaveStore.Add(askForLeaveInfo);

            var workflowData = new ApprovalInfo
            {
                Id = askForLeaveInfo.Id,
                State = "New"
            };
            WorkflowStore.Add(workflowData);

            var workflowId= await _workflowHost.StartWorkflow("AskForLeave", 1, workflowData);

            return Ok(workflowId);
        }

        [HttpPost("{eventName}/{eventKey}")]
        public async Task<IActionResult> Post(string eventName, string eventKey, [FromBody]ApprovalInfo eventData)
        {
            await _workflowHost.PublishEvent(eventName, eventKey, eventData);
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(string id)
        {
            var result = await _persistenceProvider.GetWorkflowInstance(id);
            return Json(result);
        }
    }
}

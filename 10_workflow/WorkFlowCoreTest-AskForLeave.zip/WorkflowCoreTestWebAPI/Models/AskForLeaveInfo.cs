﻿using System;

namespace WorkflowCoreTestWebAPI.Models
{
    public class AskForLeaveInfo
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int ApplyDays { get; set; }
        public DateTime ApplyDate { get; set; }
        public string Reason { get; set; }

        public ApprovalInfo DepartmentApprovalInfo { get; set; }
        public ApprovalInfo CompanyApprovalInfo { get; set; }
    }
}
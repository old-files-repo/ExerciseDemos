﻿using System;

namespace WorkflowCoreTestWebAPI.Models
{
    public class ApprovalInfo
    {
        public Guid Id { get; set; }
        public string State { get; set; }
        public string Remark { get; set; }
    }
}
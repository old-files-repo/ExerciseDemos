﻿using System;
using WorkflowCore.Interface;
using WorkflowCore.Models;
using WorkflowCoreTestWebAPI.Models;

namespace WorkflowCoreTestWebAPI.Steps
{
    public class AskForLeave : StepBody
    {
        public Guid Id { get; set; }
        public string State { get; set; }

        public override ExecutionResult Run(IStepExecutionContext context)
        {
            State = "DepartmentWaited";

            WorkflowStore.Update(new ApprovalInfo
            {
                Id = Id,
                State = State
            });
            return ExecutionResult.Next();
        }
    }
}
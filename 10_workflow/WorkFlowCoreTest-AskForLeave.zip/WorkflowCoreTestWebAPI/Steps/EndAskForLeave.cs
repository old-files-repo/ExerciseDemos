﻿using System;
using WorkflowCore.Interface;
using WorkflowCore.Models;

namespace WorkflowCoreTestWebAPI.Steps
{
    public class EndAskForLeave : StepBody
    {
        public Guid Id { get; set; }

        public override ExecutionResult Run(IStepExecutionContext context)
        {
            var askForLeaveInfo = AskForLeaveStore.Get(Id);

            var workflowInfo = WorkflowStore.Get(Id);

            return ExecutionResult.Next();
        }
    }
}
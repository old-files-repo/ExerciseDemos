﻿using System;
using WorkflowCore.Interface;
using WorkflowCore.Models;
using WorkflowCoreTestWebAPI.Models;

namespace WorkflowCoreTestWebAPI.Steps
{
    public class CompanyApproval : StepBody
    {
        public Guid Id { get; set; }
        public string State { get; set; }
        public string Remark { get; set; }

        public override ExecutionResult Run(IStepExecutionContext context)
        {
            AskForLeaveStore.AddCompanyApprovalInfo(new ApprovalInfo
            {
                Id = Id,
                State = State,
                Remark = Remark
            });

            WorkflowStore.Update(new ApprovalInfo
            {
                Id = Id,
                State = State
            });

            return ExecutionResult.Next();
        }
    }
}
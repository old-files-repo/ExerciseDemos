﻿using WorkflowCore.Interface;
using WorkflowCore.Models;
using WorkflowCoreTestWebAPI.Models;
using WorkflowCoreTestWebAPI.Steps;

namespace WorkflowCoreTestWebAPI.WorkFlows
{
    public class AskForLeaveWorkflow : IWorkflow<ApprovalInfo>
    {
        public string Id => "AskForLeave";
        public int Version => 1;

        public void Build(IWorkflowBuilder<ApprovalInfo> builder)
        {
            builder
                .StartWith<AskForLeave>()
                    .Input(step => step.Id, data => data.Id)
                    .Output(data => data.State, step => step.State)
                
                .WaitFor("DepartmentApprovalEvent", (data, context) => context.Workflow.Id)
                    .Output(data => data.State, step => ((ApprovalInfo)step.EventData).State)
                    .Output(data => data.Remark, step => ((ApprovalInfo)step.EventData).Remark)
                .Then<DepartmentApproval>()
                    .Input(step => step.Id, data => data.Id)
                    .Input(step => step.State, data => data.State)
                    .Input(step => step.Remark, data => data.Remark)
                    .Output(data => data.State, step => step.State)

                .If(data => data.State == "CompanyWaited").Do(next => next
                    .StartWith(context => ExecutionResult.Next())
                    .WaitFor("CompanyApprovalEvent", (data, context) => context.Workflow.Id)
                        .Output(data => data.State, step => ((ApprovalInfo)step.EventData).State)
                        .Output(data => data.Remark, step => ((ApprovalInfo)step.EventData).Remark)
                    .Then<CompanyApproval>()
                        .Input(step => step.Id, data => data.Id)
                        .Input(step => step.State, data => data.State)
                        .Input(step => step.Remark, data => data.Remark)
                )

                .Then<EndAskForLeave>()
                    .Input(step => step.Id, data => data.Id);
        }
    }
}
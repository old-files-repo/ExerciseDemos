﻿namespace WorkFlowCoreTest_AskForLeave.Models
{
    public class CompanyApprovalEventModel
    {
        public ApprovalInfo CompanyApprovalInfo { get; set; }
        public string CompanyApprovalEventKey { get; set; }
    }
}
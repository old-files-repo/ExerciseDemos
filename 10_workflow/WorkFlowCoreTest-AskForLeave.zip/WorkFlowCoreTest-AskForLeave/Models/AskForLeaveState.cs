﻿namespace WorkFlowCoreTest_AskForLeave.Models
{
    public enum AskForLeaveState
    {
        DepartmentWaited = 2,
        CompanyWaited = 5,
        Approved = 8,
        Denied = 9
    }
}
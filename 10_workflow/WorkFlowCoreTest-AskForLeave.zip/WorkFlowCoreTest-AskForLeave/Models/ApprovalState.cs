﻿namespace WorkFlowCoreTest_AskForLeave.Models
{
    public enum ApprovalState
    {
        Approved = 0,
        Denied = 1
    }
}
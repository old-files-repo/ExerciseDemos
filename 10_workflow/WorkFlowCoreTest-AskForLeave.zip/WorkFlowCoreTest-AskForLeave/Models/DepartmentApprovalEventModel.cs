﻿namespace WorkFlowCoreTest_AskForLeave.Models
{
    public class DepartmentApprovalEventModel
    {
        public ApprovalInfo DepartmentApprovalInfo { get; set; }
        public string DepartmentApprovalEventKey { get; set; }
    }
}